CREATE DATABASE IF NOT EXISTS `UTILISATEURS` DEFAULT CHARACTER SET UTF8MB4 COLLATE utf8_general_ci;
USE `UTILISATEURS`;

CREATE TABLE `PLACE` (
  `num_place` VARCHAR(42),
  `statut_place` VARCHAR(42),
  `num_liste` VARCHAR(42),
  PRIMARY KEY (`num_place`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `RESERVATION` (
  `num_reservation` VARCHAR(42),
  `num_utilisateur` VARCHAR(42),
  `num_place` VARCHAR(42),
  `datedebut` VARCHAR(42),
  `datefin` VARCHAR(42),
  `num_place_1` VARCHAR(42),
  `num_utilisateur_1` VARCHAR(42),
  PRIMARY KEY (`num_reservation`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `UTILISATEUR` (
  `num_utilisateur` VARCHAR(42),
  `nom_utilisateur` VARCHAR(42),
  `prenom_utilisateur` VARCHAR(42),
  PRIMARY KEY (`num_utilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

ALTER TABLE `RESERVATION` ADD FOREIGN KEY (`num_utilisateur_1`) REFERENCES `UTILISATEUR` (`num_utilisateur`);
ALTER TABLE `RESERVATION` ADD FOREIGN KEY (`num_place_1`) REFERENCES `PLACE` (`num_place`);